function d2fdx2= NSd2fdx2(times, x, p, more)
nobs = length(times);
d2fdx2 = zeros(nobs, 1, 1, 1);
end