function fnval = findif_var_fun(times,y,p,more)

fnval = more.var.fn(times,y,p,more.more);

end

