function fnval = exp_fn(t,x,pars,more)

fnval = exp(x);

end

