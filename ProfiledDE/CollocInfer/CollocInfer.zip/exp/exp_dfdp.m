function dfdpval = exp_dfdp(t,x,pars,more)

[m,n] = size(x);
dfdpval = zeros(m,n,length(pars));

end

