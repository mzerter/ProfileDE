function f = sinin(t,p)

f = sin(t.*(4*pi));

end