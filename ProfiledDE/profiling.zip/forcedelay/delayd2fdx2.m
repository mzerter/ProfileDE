function r = delayd2fdx2(t,fd_cell,p,force)

r = cell(1,1,1);
r{1} = 0;