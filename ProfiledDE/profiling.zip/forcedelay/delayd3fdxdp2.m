function r = delayd3fdxdp2(t,fd_cell,p,force)

r = cell(1,1,3,3);
r(:) = {0};

