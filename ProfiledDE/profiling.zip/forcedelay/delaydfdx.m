function r = delaydfdx(t,fd_cell,p,force)

r = cell(1,1);
r{1} = p(1);